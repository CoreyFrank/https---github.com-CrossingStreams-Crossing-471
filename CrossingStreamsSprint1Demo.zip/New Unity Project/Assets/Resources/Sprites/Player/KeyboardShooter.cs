﻿using UnityEngine;
using System.Collections;

public class KeyboardShooter : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.UpArrow)) {
			SpawningUtility.SpawnBullet (gameObject.transform.position, .6f, Vector2.up);
		}
		if (Input.GetKeyDown (KeyCode.RightArrow)) {
			SpawningUtility.SpawnBullet (gameObject.transform.position, .6f, Vector2.right);
		}
		if (Input.GetKeyDown (KeyCode.DownArrow)) {
			SpawningUtility.SpawnBullet (gameObject.transform.position, .6f, Vector2.down);
		}
		if (Input.GetKeyDown (KeyCode.LeftArrow)) {
			SpawningUtility.SpawnBullet (gameObject.transform.position, .6f, Vector2.left);
		}
	}
}
