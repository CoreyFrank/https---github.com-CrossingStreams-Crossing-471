﻿using UnityEngine;
using System.Collections;

/**
 * COSC 470 2016 Team B project
 * Team: Ben Ward, Billy Spelchan, Corey Frank, Daniel Atkinson, Marc-Andrew Dunwell
 * Project: Crossing Streams
 * Licence: MIT License.
 * 
 * Control behaviour where cursor keys will shoot in indicated direction
 * Test by applying to an object on the screen then when running use cursor keys to validate.
 * Versions:
 * - BT-131	Link Character and Projectile by Billy D. Spelchan
 */
public class KeyboardShooter2 : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.UpArrow)) {
			SpawningUtility.SpawnBullet (gameObject.transform.position, .6f, Vector2.up);
		}
		if (Input.GetKeyDown (KeyCode.RightArrow)) {
			SpawningUtility.SpawnBullet (gameObject.transform.position, .6f, Vector2.right);
		}
		if (Input.GetKeyDown (KeyCode.DownArrow)) {
			SpawningUtility.SpawnBullet (gameObject.transform.position, .6f, Vector2.down);
		}
		if (Input.GetKeyDown (KeyCode.LeftArrow)) {
			SpawningUtility.SpawnBullet (gameObject.transform.position, .6f, Vector2.left);
		}
	}
}
